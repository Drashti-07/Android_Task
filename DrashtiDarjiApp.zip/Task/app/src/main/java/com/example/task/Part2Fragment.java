package com.example.task;

import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Part2Fragment extends Fragment {

    private EditText editTextNumber;
    private Button buttonGenerate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        editTextNumber = view.findViewById(R.id.edit_text_number);
        buttonGenerate = view.findViewById(R.id.button_generate);
        final LinearLayout layout = view.findViewById(R.id.layout_squares);

        editTextNumber.setInputType(InputType.TYPE_CLASS_NUMBER);

        buttonGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.removeAllViews();
                int count;
                try {
                    count = Integer.parseInt(editTextNumber.getText().toString());
                } catch (NumberFormatException e) {
                    count = 0;
                }
                generateGrid(count, layout);
            }
        });
    }

    private void generateGrid(int count, LinearLayout layout) {
        int squareSize = 100; // Size of each square
        int numColumns = 10;  // Number of columns

        for (int i = 0; i < count; i++) {
            LinearLayout row = new LinearLayout(getContext());
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    squareSize
            ));
            row.setOrientation(LinearLayout.HORIZONTAL);

            for (int j = 0; j < numColumns && (i * numColumns + j) < count; j++) {
                View square = new View(getContext());
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                        squareSize,
                        squareSize
                );
                params.setMargins(2, 2, 2, 2); // Margin between squares
                square.setLayoutParams(params);
                square.setBackgroundColor(((i + j) % 2 == 0) ? 0xFF00FF00 : 0xFFFF0000); // Alternate colors
                row.addView(square);
            }

            layout.addView(row);
        }
    }
}